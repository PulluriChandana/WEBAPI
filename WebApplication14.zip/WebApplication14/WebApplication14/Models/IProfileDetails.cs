﻿namespace WebApplication14.Models
{
    public interface IProfileDetails
    {
        public List<Profile> GetProfiles();
    }
    class ProfileDetails : IProfileDetails
    {
        public List<Profile> GetProfiles()
        {
            var profiles = new List<Profile>()
            {
                new Profile()
                {
                    Id=1,
                    Name="Chandana",
                    Email="Chandu@gmail.com",
                    DateofBirth="22-05-2024"
                },
                new Profile()
                {
                    Id=2,
                    Name="Meghana",
                    Email="Meghuu@gmail.com",
                    DateofBirth="10-05-2024"
                },
                new Profile()
                {
                    Id=3,
                    Name="Sreevani",
                    Email="Vani@gmail.com",
                    DateofBirth="14-05-2024"
                }
            };
            return profiles;
        }
    }
}

