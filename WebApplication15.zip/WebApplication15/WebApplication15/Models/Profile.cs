﻿namespace WebApplication14.Models
{
    public class Profile
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string DateofBirth { get; set; }
    }
}
