﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApplication14.Models;

namespace WebApplication15.Data
{
    public class WebApplication15Context : DbContext
    {
        public WebApplication15Context (DbContextOptions<WebApplication15Context> options)
            : base(options)
        {
        }

        public DbSet<WebApplication14.Models.Profile> Profile { get; set; } = default!;
    }
}
