﻿namespace WebApplication9.Models
{
    public class Account
    {
        public int AccountID { get; set; }
        public string AccountNUmber { get; set; }
        public string CustomerName { get; set; }
        public double Balance { get; set; }
        public string Address { get; set; }
    }
}
