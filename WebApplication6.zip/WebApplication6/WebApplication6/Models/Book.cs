﻿namespace WebApplication6.Models
{
    /*public class Library
    {
        public int LibraryID { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public ICollection<Book> Books { get; set; } //Navigation Property
    }*/
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public int YearPublished { get; set; }
        public int LibraryID { get; set; } //Foregin Key
        //public Library Library { get; set; } //Navigation Property

    }
}
