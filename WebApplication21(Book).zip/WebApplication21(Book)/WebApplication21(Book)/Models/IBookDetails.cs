﻿namespace WebApplication21_Book_.Models
{
    public interface IBookDetails
    {
        IEnumerable<Book> GetBooks();
        Book GetBook(int id);
        void AddBook(Book book);
        void UpgradeBook(Book book);
        void DeleteBook(int id);
    }
}
