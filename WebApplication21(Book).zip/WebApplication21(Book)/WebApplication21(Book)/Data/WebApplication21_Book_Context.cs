﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebApplication21_Book_.Models;

namespace WebApplication21_Book_.Data
{
    public class WebApplication21_Book_Context : DbContext
    {
        public WebApplication21_Book_Context (DbContextOptions<WebApplication21_Book_Context> options)
            : base(options)
        {
        }

        public DbSet<WebApplication21_Book_.Models.Book> Book { get; set; } = default!;
    }
}
