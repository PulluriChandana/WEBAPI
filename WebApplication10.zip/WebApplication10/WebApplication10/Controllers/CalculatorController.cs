﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace WebApplication10.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CalculatorController : ControllerBase
    {
        [HttpGet("add")]
        public IActionResult Add(int a,int b)
        {
            return Ok(a + b);
        }
        [HttpGet("subtract")]
        public IActionResult Subtract(int a, int b)
        {
            return Ok(a - b);
        }
        [HttpGet("multiply")]
        public IActionResult Multiply(int a, int b)
        {
            return Ok(a * b);
        }
        [HttpGet("division")]
        public IActionResult Division(int a, int b)
        {
            return Ok(a / b);
        }
    }
}
