﻿using Microsoft.AspNetCore.Mvc;
using WebApplication13.Models;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace WebApplication13.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountsController : ControllerBase
    {
        IAccountDetails m_accountDetails;
        public AccountsController(IAccountDetails accountDetails)
        {
            m_accountDetails = accountDetails;
        }
        // GET: api/<AccountsController>
        [HttpGet]
        public IEnumerable<Account> Get()
        {
            return m_accountDetails.GetAccounts();
        }

        // GET api/<AccountsController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<AccountsController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<AccountsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<AccountsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
