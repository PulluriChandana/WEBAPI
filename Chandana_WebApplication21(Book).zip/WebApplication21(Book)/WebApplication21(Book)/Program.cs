using WebApplication21_Book_.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using WebApplication21_Book_.Data;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddDbContext<WebApplication21_Book_Context>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("WebApplication21_Book_Context") ?? throw new InvalidOperationException("Connection string 'WebApplication21_Book_Context' not found.")));

// Add services to the container.
//builder.Services.AddTransient<IBookDetails, IBookDetails>();

builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
}
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
