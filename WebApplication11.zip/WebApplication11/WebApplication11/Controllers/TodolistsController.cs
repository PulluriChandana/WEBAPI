﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApplication11.Data;
using WebApplication11.Models;

namespace WebApplication11.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TodolistsController : ControllerBase
    {
        private readonly WebApplication11Context _context;

        public TodolistsController(WebApplication11Context context)
        {
            _context = context;
        }

        // GET: api/Todolists
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Todolist>>> GetTodolist()
        {
          if (_context.Todolist == null)
          {
              return NotFound();
          }
            return await _context.Todolist.ToListAsync();
        }

        // GET: api/Todolists/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Todolist>> GetTodolist(int id)
        {
          if (_context.Todolist == null)
          {
              return NotFound();
          }
            var todolist = await _context.Todolist.FindAsync(id);

            if (todolist == null)
            {
                return NotFound();
            }

            return todolist;
        }

        // PUT: api/Todolists/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<IActionResult> PutTodolist(int id, Todolist todolist)
        {
            if (id != todolist.Id)
            {
                return BadRequest();
            }

            _context.Entry(todolist).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!TodolistExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Todolists
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<Todolist>> PostTodolist(Todolist todolist)
        {
          if (_context.Todolist == null)
          {
              return Problem("Entity set 'WebApplication11Context.Todolist'  is null.");
          }
            _context.Todolist.Add(todolist);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetTodolist", new { id = todolist.Id }, todolist);
        }

        // DELETE: api/Todolists/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTodolist(int id)
        {
            if (_context.Todolist == null)
            {
                return NotFound();
            }
            var todolist = await _context.Todolist.FindAsync(id);
            if (todolist == null)
            {
                return NotFound();
            }

            _context.Todolist.Remove(todolist);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool TodolistExists(int id)
        {
            return (_context.Todolist?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
