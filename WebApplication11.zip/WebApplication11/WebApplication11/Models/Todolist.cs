﻿namespace WebApplication11.Models
{
    public class Todolist
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public bool isComplete {  get; set; }
    }
}
