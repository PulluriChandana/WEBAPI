﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class PersonalController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
