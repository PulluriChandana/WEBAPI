﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class SampleController : Controller
    {
        public string Index()
        {
            return "Hello World";
        }
        public string FirstName()
        {
            return "Pulluri";
        }
        public string LastName()
        {
            return "Chandana";
        }

    }
}
