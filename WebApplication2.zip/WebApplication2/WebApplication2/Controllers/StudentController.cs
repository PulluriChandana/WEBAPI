﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication2.Controllers
{
    public class StudentController : Controller
    {
        public string Index()
        {
            return "Index";
        }
        public int GetRollNo()
        {
            return 11;
        }
        public string GetName()
        {
            return "Pulluri Chandana";
        }
    }
}
