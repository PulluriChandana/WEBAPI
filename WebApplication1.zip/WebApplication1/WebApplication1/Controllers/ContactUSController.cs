﻿using Microsoft.AspNetCore.Mvc;

namespace WebApplication1.Controllers
{
    public class ContactUSController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
